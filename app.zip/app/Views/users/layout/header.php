<!-- <nav class="relative w-full flex flex-wrap items-center justify-between py-4 bg-gray-100 text-gray-500 hover:text-gray-700 focus:text-gray-700 shadow-lg">
    <div class="container-fluid w-full flex flex-wrap items-center justify-between px-6">
        <div class="container-fluid">
            <a class="flex items-center text-gray-900 hover:text-gray-900 focus:text-gray-900 mt-1 lg:mt-0 mr-1" href="#">
                <img src="<?= base_url('images/fundacion kallpa.jpg') ?>" style="height: 60px" alt="" loading="lazy" title="Fundacion Kallpa"/>
            </a>
        </div>
    </div> -->
<!-- </nav> -->

<nav class="relative w-full flex flex-wrap items-center justify-between py-3 bg-gray-100 text-gray-500 hover:text-gray-700 focus:text-gray-700 shadow-lg">
    <div class="container-fluid w-full flex flex-wrap items-center justify-between px-6">
        <div class="container-fluid">
        <a class="text-xl text-black" href="#"><img src="<?= base_url('img/logo.jpg') ?>" style="height: 60px" alt="" loading="lazy" title="Fundacion Kallpa"/></a>
        </div>
    </div>
</nav>